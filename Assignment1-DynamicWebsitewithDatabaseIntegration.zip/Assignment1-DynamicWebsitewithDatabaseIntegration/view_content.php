<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View page - Assignment 1 PH</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<header>
    <img src="logoGeorgian.png" alt="Logo" class="logo">
    <div class="logo">Student Portal</div>
    <nav>
        <ul>
            <li><a href="index.html">Register here</a></li>
            <li><a href="view_content.php">View registered students</a></li>
        </ul>
    </nav>
</header>
<main>
    <h1>View Content</h1>
    <?php include 'display_content.php'; ?>
</main>
<footer>Footer Content</footer>
</body>
</html>
